# reference-lecture-4-2021
Lecture 4 reference bot. Implements a more efficient card allocation algorithm by precomputing card strengths and utilizing optimized python libraries.
